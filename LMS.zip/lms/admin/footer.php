<div class="pull-right">
		<footer>
           <p>NDDU LMS 2021-2022</p>
        <footer>
</div>