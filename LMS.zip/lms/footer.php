<center>
		<footer>
		<p>NDDU LMS Copyright 2021</p>
		</footer>
</center>

