				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/NDDUseal.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc">Notre Dame of Dadiangas University</p>
							<h3>

							<p>NDDU LMS</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												
								</div>		
						</div>		
				</div>