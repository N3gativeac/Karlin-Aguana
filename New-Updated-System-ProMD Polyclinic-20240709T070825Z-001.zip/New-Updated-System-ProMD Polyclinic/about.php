 <!-- Masthead-->
         
		<header class="masthead  h-25">
            <div class="container h-50">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4 page-title">
                    	<h3 class="text-white">About Us</h3>
                        
                    </div>
                    
                </div>
            </div>
        </header>

    <section class="page-section">
        <div class="container" style="word-wrap: break-word">
			<?php echo html_entity_decode($_SESSION['setting_about_content']) ?>
            
        </div>
        </section>